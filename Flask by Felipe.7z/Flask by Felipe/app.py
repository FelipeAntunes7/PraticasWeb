from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

class Usuario:
    def __init__(self, email, senha_hash):
        self.email = email
        self.senha_hash = senha_hash

usuarios = []  # Lista para armazenar os detalhes dos usuários

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']

        usuario = next((u for u in usuarios if u.email == email), None)
        if usuario and check_password_hash(usuario.senha_hash, senha):
            flash('Login bem-sucedido!', 'success')
            return redirect(url_for('mercado'))  # Redirecionar para a página de mercado após o login
        else:
            flash('Credenciais inválidas. Por favor, tente novamente.', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        confirmar_senha = request.form['confirmar_senha']

        if not email or not senha or not confirmar_senha:
            flash('Por favor, preencha todos os campos.', 'danger')
            return redirect(url_for('cadastro'))

        if senha != confirmar_senha:
            flash('As senhas não coincidem. Por favor, tente novamente.', 'danger')
            return redirect(url_for('cadastro'))

        if any(u.email == email for u in usuarios):
            flash('Este email já está em uso. Por favor, escolha outro.', 'danger')
            return redirect(url_for('cadastro'))

        senha_hash = generate_password_hash(senha)
        novo_usuario = Usuario(email, senha_hash)
        usuarios.append(novo_usuario)
        flash('Cadastro realizado com sucesso! Faça login agora.', 'success')
        return redirect(url_for('login'))

    return render_template('cadastro.html')

@app.route('/mercado')
def mercado():
    # Aqui você pode retornar o template ou realizar outras ações após o login
    return render_template('mercado.html')

if __name__ == '__main__':
    app.run(debug=True)


































